#!/usr/bin/env python
import random
import math
import numpy as np
import tf
import rospy
#from tf import *
# import pqp_server.srv
#from pqp_server.srv import *
# def is_collision_free(T, R):
#     if len(T) != 3 or len(R) != 9:
#         print "Incorrect list size for pqp request"
#         return True
#     rospy.wait_for_service('pqp_server')
#     try:
#         pqp_server = rospy.ServiceProxy('pqp_server', pqpRequest)
#         result = pqp_server(T, R)
#         return result
#     except rospy.ServiceException, e:
#         print "Service Call Failed: %s"%e
#
#
# # to verify unit maginatude
# def magnitude(q):
#     sum = 0
#     for i in q:
#         sum += (i) ** 2
#     return (sum) ** 0.5
#
#
# # In[ ]:
#
#
# # tf.transformations.quaternion_matrix(quaternion)
#
#
# # In[ ]:
#
#
# # ordered with increasing scores, first is the nearest
# def k_nearest_points(points, new, k):
#     top = []
#     scores = list(points.map(lambda p: Point.euclidean_distance(new.t, p.t)))
#     for i in range(k):
#         min = None
#         min_index = None
#         for j in range(len(scores)):
#             if j not in top:
#                 if not min or min > scores[j]:
#                     min = scores[j]
#                     min_index = j
#         top.append(min_index)
#     return [points[i] for i in top]
#
#
# # In[65]:


# use class variables for x,y,z ranges for generating random translationals,
class Point(object):
    def __init__(self, t = None, r = None):
        if t and r:
            self.t = t
            self.r = r
        else:
            self.t = Point.generate_random_translational()
            self.r = Point.generate_random_quarternion()

    @staticmethod
    def generate_random_quarternion():
        s = random.random()
        sigma_1 = (1 - s) ** 0.5
        sigma_2 = (s) ** 0.5
        theta_1 = 2 * math.pi * random.random()
        theta_2 = 2 * math.pi * random.random()
        w = math.cos(theta_2) * sigma_2
        x = math.sin(theta_1) * sigma_1
        y = math.cos(theta_1) * sigma_1
        z = math.sin(theta_2) * sigma_2
        return [w, x, y, z]

    @staticmethod
    def generate_random_translational():
        x = -10 + random.random()*20
        y = -10 + random.random()*20
        z = random.random()*2
        return [x, y, z]

    # should we interpolate by number of points
    # based on dimensions of the piano
    @staticmethod
    def interpolated_points(p1, p2):
        # make number of points a function of the euclidean distance
        parts = 5
        trans = Point.translational_interpolated_points(p1.t, p2.t, parts)
        # rot = Point.rotational_interpolated_points(p1.r, p2.r, parts)
        return [Point(trans[i], p1.r) for i in range(parts)]

    # what is epsilon?
    @staticmethod
    def rotational_interpolated_points(q1, q2, parts):
        f_array = np.linspace(0, 1, parts + 1)
        points = []
        r = None
        s = None
        epsilon = 0.001
        lam = np.inner(q1, q2)
        if lam < 0:
            q2 = [-k for k in q2]
            lam = -lam
        for f in f_array:
            # what is epsilon?
            if abs(1 - lam) < epsilon:
                r = 1 - f
                s = f
            else:
                alpha = math.acos(lam)
                gamma = 1 / math.sin(alpha)
                r = math.sin((1 - f) * alpha) * gamma
                s = math.sin(f * alpha) * gamma
            points.append([r * q1[0] + s * q2[0], r * q1[1] + s * q2[1], r * q1[2] + s * q2[2], r * q1[3] + s * q1[3]])
        return points

    @staticmethod
    def translational_interpolated_points(p1, p2, parts):
        return list(zip(np.linspace(p1[0], p2[0], parts + 1), np.linspace(p1[1], p2[1], parts + 1)))

    @staticmethod
    def euclidean_distance(p1, p2):
        return ((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2) ** 0.5

    @staticmethod
    def distance(p1, p2, wt, wr):
        return wt * Point.euclidean_distance(p1.t, p2.t) + wr * p1.rotational_distance(p2)

    @staticmethod
    def slope(p1, p2):
        if p2[1] - p1[1] == 0:
            return None
        return (p2[1] - p1[1]) / (p2[0] - p1[0])

    def rotational_distance(self, q):
        lam = np.inner(self.r, q)
        return (1 - abs(lam))


# In[ ]:


#  def isReachable(vertices, s, d):
#     # Mark all the vertices as not visited
#     visited =[False]*(self.V)

#     # Create a queue for BFS
#     queue=[]

#     # Mark the source node as visited and enqueue it
#     queue.append(s)
#     visited[s] = True

#     while queue:

#         #Dequeue a vertex from queue
#         n = queue.pop(0)

#         # If this adjacent node is the destination node,
#         # then return true
#          if n == d:
#             return True

#         #  Else, continue to do BFS
#         for i in self.graph[n]:
#             if visited[i] == False:
#                 queue.append(i)
#                 visited[i] = True
#      # If BFS is complete without visited d
#      return False


# In[ ]:

def main():
    count = 0
	print("started")
    while count < 1:
	print("inside while")
        new = Point()
        t = new.t
        r = new.r
        q_matrix = tf.transformations.quarternion_matrix(r)
        print(q_matrix)
        count += 1
        # if is_collision_free(new):







if __name__ == "__main__":
	print("main called")
	main()

# adjaceny_dict = {}
# for i in range(1000):
#     new = Point()
    # check if collision free
    # if true add it to the list of vertices NOT YET
    # key as the point and value is an empty list
    # if len of adjacency dict is less than = k just add connections to all nodes if no collision
    # else
    # call k nearest neighbors, and first check if the connection is possible
    # if yes add a connection
    # go to next possible connection, keep a list connections mad and check if the node with possible connection is
    # connected to any of the ones in the list if yes no connection if not make the connection

# In[ ]:


# second
# Question
#
# State -> pose(x, y, theta) and twist(linear and angular
# velocities)
