#!/usr/bin/env python

import rospy
from pqp_server.srv import *
import random
import math
import numpy as np
import tf
import operator
import heapq
import time
from gazebo_msgs.msg import ModelState
from geometry_msgs.msg import Pose, Twist
import pickle
import os


def talker(p):
    print("talker", p.t, p.r)
    pub = rospy.Publisher('/gazebo/set_model_state', ModelState, queue_size=10)
    rospy.init_node('talker',anonymous=True)
    rate = rospy.Rate(10)
    if not rospy.is_shutdown():
        x = ModelState()
        x.model_name = "piano2"
        x.pose = Pose()
        x.pose.position.x = p.t[0]
        x.pose.position.y = p.t[1]
        x.pose.position.z = p.t[2]
        x.pose.orientation.x = p.r[0]
        x.pose.orientation.y = p.r[1]
        x.pose.orientation.z = p.r[2]
        x.pose.orientation.w = p.r[3]
        x.twist = Twist()
        x.reference_frame = "world"
        print("publishing x")
        pub.publish(x)
        rate.sleep()
class Point(object):
    def __init__(self, t = None, r = None):
        if t and r:
            self.t = t
            self.r = r
        else:
            self.t = Point.generate_random_translational()
            self.r = Point.generate_random_quarternion()

    @staticmethod
    def generate_random_quarternion():
        s = random.random()
        sigma_1 = (1 - s) ** 0.5
        sigma_2 = (s) ** 0.5
        theta_1 = 2 * math.pi * random.random()
        theta_2 = 2 * math.pi * random.random()
        w = math.cos(theta_2) * sigma_2
        x = math.sin(theta_1) * sigma_1
        y = math.cos(theta_1) * sigma_1
        z = math.sin(theta_2) * sigma_2
        return [w, x, y, z]

    @staticmethod
    def generate_random_translational():
        x=-2+random.random()*10 #red
        y=random.random()*10 #green
        #x = -10 + random.random()*20
        #y = -10 + random.random()*20
        z = random.random()*2 #blue
        return [x, y, z]

    # should we interpolate by number of points
    # based on dimensions of the piano
    @staticmethod
    def interpolated_points(p1, p2):
        # make number of points a function of the euclidean distance
        parts = 5
        trans = Point.translational_interpolated_points(p1.t, p2.t, parts)
        # rot = Point.rotational_interpolated_points(p1.r, p2.r, parts)
        return [Point(trans[i], p1.r) for i in range(parts)]

    # what is epsilon?
    @staticmethod
    def rotational_interpolated_points(q1, q2, parts):
        f_array = np.linspace(0, 1, parts + 1)
        points = []
        r = None
        s = None
        epsilon = 0.001
        lam = np.inner(q1, q2)
        if lam < 0:
            q2 = [-k for k in q2]
            lam = -lam
        for f in f_array:
            # what is epsilon?
            if abs(1 - lam) < epsilon:
                r = 1 - f
                s = f
            else:
                alpha = math.acos(lam)
                gamma = 1 / math.sin(alpha)
                r = math.sin((1 - f) * alpha) * gamma
                s = math.sin(f * alpha) * gamma
            points.append([r * q1[0] + s * q2[0], r * q1[1] + s * q2[1], r * q1[2] + s * q2[2], r * q1[3] + s * q1[3]])
        return points

    @staticmethod
    def translational_interpolated_points(p1, p2, parts):
        return list(zip(np.linspace(p1[0], p2[0], parts + 1), np.linspace(p1[1], p2[1], parts + 1), np.linspace(p1[2], p2[2], parts + 1)))

    @staticmethod
    def euclidean_distance(p1, p2):
        return ((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2 + (p1[2] - p2[2])**2) ** 0.5

    @staticmethod
    def distance(p1, p2, wt, wr):
        return wt * Point.euclidean_distance(p1.t, p2.t) + wr * p1.rotational_distance(p2)

    @staticmethod
    def slope(p1, p2):
        if p2[1] - p1[1] == 0:
            return None
        return (p2[1] - p1[1]) / (p2[0] - p1[0])
    @staticmethod
    def rotational_distance(q1, q2):
        lam = np.inner(q1, q2)
        return (1 - abs(lam))

def is_collision_free(p):
    T = p.t
    q_matrix = tf.transformations.quaternion_matrix(p.r)
    R = [q_matrix[i][j] for j in range(3) for i in range(3)]
    # print(T)
    # print(R)
    if len(T) != 3 or len(R) != 9:
        print "Incorrect for pqp request"
        return True
    rospy.wait_for_service('pqp_server')
    try:
        pqp_server = rospy.ServiceProxy('pqp_server', pqpRequest)
        result = pqp_server(T, R)
        return result
    except rospy.ServiceException, e:
        print "Service Call Failed: %s"%e

def k_nearest_points(points, new, k):
    top = []
    scores = list(map(lambda p: Point.euclidean_distance(new.t, p.t),points))
    # min_euc_dist = min(scores)
    # scores = list(map( lambda s: s + min_euc_dist*rotational_distance()))
    for i in range(k):
        min = None
        min_index = None
        for j in range(len(scores)):
            if j not in top:
                if not min or min > scores[j]:
                    min = scores[j]
                    min_index = j
        top.append(min_index)
    return [points[i] for i in top]

def nearest_collision_free_point(road_map,target):
    scores_dict = {}
    for i in road_map.keys():
        scores_dict[i] =  Point.euclidean_distance(target.t, i.t)
    sorted_scores = sorted(scores_dict.items(), key = operator.itemgetter(1))
    for s in sorted_scores:
        if is_collision_free(s[0]):
            return s[0]

def are_points_collision_free(points):
    for point in points:
        if not is_collision_free(point):
            return False
    return True

class PriorityQueue():
    def __init__(self):
        self.elements = []

    def empty(self):
        return len(self.elements) == 0

    def put(self, item, priority):
        heapq.heappush(self.elements, (priority, item))

    def get(self):
        return heapq.heappop(self.elements)
def get_path_length(p):
    dist = 0
    for i in range(1,len(p)):
        dist += Point.euclidean_distance(p[i-1].t,p[i].t)
    return dist

class search():
    def __init__(self,start,goal,road_map):
        self.start = start
        self.goal = goal
        self.road_map = road_map
    def heuristic(self,next):
    # x:0, y:1
        return Point.euclidean_distance(self.goal.t,next.t)

    def a_star_search(self):
        # print("a start search")
        # print("from ",self.start.t, " to ", self.goal.t)
        frontier = PriorityQueue()
        frontier.put(self.start, 0)
        came_from = {}
        cost_so_far = {}
        came_from[self.start] = self.start
        cost_so_far[self.start] = 0
        priority=0
        number_of_nodes_popped = 0
        while not frontier.empty():
            poppedNode = frontier.get()
            current = poppedNode[1]
            number_of_nodes_popped += 1
            # print("current f value",poppedNode[0])
            # print("popped node",current)
            if current == self.goal:
                print("success")
                path = []
                current = self.goal
                path.append(current)
                while current != self.start:
                    current = came_from[current]
                    path.append(current)
                path = [self.goal] + path + [self.start]
                path_distance = get_path_length(path)
                # print("path length",len(path)+2)
                # print("path distance", path_distance)
                return path[::-1], path_distance
                break
            for next in self.road_map[current]:
                new_cost = cost_so_far[current] + Point.euclidean_distance(current.t,next.t) #g.cost(current, next)
                if next not in cost_so_far or new_cost < cost_so_far[next]:
                    cost_so_far[next] = new_cost
                    priority = new_cost + self.heuristic(next)
                    frontier.put(next, priority)
                    came_from[next] = current
        return None
        # print("number of nodes popped",number_of_nodes_popped)
def prm_star(d, n):
    return math.exp(1)*(1+(1/d))*math.log(n)


def sample_query_points(n):
    start_locations = []
    goal_locations = []
    while len(start_locations)<n:
        t = Point.generate_random_translational()
        r = [1,0,0,0,1,0,0,0,1]
        p = Point(t,r)
        if is_collision_free(p):
            start_locations.append(p)
    while len(goal_locations)<n:
        t = Point.generate_random_translational()
        r = [1,0,0,0,1,0,0,0,1]
        p = Point(t,r)
        if is_collision_free(p):
            goal_locations.append(p)
    return start_locations, goal_locations

def does_pickle_exist():
    if os.path.isfile('road_map.pickle'):
        return True
    return False

def non_connected_neighbors(neighbors, road_map):
    l = len(neighbors)
    r_indices = []
    for i in range(1,l):
        for j in range(i):
            if is_reachable(neighbors[j], neighbors[i], road_map):
                r_indices.append(i)
                break
    return [neighbors[i] for i in range(l) if i not in r_indices]
def is_reachable(a,b,road_map):
    visited = {}
    queue = []
    queue.append(a)
    visited[a] = True
    while queue:
        n = queue.pop()

        if n==b:
            return True
        for i in road_map[n]:
            if i not in visited:
                queue.append(i)
                visited[i] = True
    return True

def create_road_map(number_of_nodes,k=5,type=0):
    vertices = []
    road_map = {}
    count = 0
    k = 5
    while count < number_of_nodes:
        new = Point()
        if is_collision_free(new):
            if len(vertices) > k:
                if type == 2:
                    k = int(prm_star(7,len(vertices)))
                nearest_points = k_nearest_points(vertices, new, k)
                if type == 1:
                    nearest_points = non_connected_neighbors(nearest_points, road_map)
                for point in nearest_points:
                    i_points = Point.interpolated_points(point, new)
                    if are_points_collision_free(i_points):
                        temp = road_map.get(point, [])
                        temp.append(new)
                        road_map[point] = temp
                        road_map[new] = [point]
            else:
                n_Vertices = []
                if type == 1:
                    n_vertices = non_connected_neighbors(vertices, road_map)
                else:
                    n_vertices = vertices
                for vertex in n_vertices:
                    i_points = Point.interpolated_points(vertex, new)
                    if are_points_collision_free(i_points):
                        temp = road_map.get(vertex, [])
                        temp.append(new)
                        road_map[vertex] = temp
                        road_map[new] = [vertex]

            vertices.append(new)
            count += 1
    print("road map constructed")
    return vertices, road_map
def execute_search_on_locations(start_locations, goal_locations, road_map):
    path_lengths = []
    path_distances = []
    for i in range(len(start_locations)):
        # print("===================")
        nearest_point_to_start = nearest_collision_free_point(road_map, start_locations[i])
        nearest_point_to_goal  = nearest_collision_free_point(road_map, goal_locations[i])
        s = search(nearest_point_to_start, nearest_point_to_goal, road_map)
        path, path_distance = s.a_star_search()
        path_lengths.append(len(path))
        path_distances.append(path_distance)
        # print("===================")
        # if path:
        #     for p in path:
        #         talker(p)
        #         time.sleep(1)
    return path_lengths, path_distances

def main():
    start_locations, goal_locations = sample_query_points(50)
    print("50 query samples generated")

    vertices = []
    road_map = {}
    # if does_pickle_exist():
    #     file = open("road_map.pickle","rb")
    #     vertices, road_map = pickle.load(file)
    #     file.close()
    # else:
    #     vertices, road_map = create_road_map(200,3,1)
    #     file = open("road_map.pickle","wb")
    #     pickle.dump([vertices, road_map], file)
    #     file.close()
    for i in range(3):
        print("running for type ",i )
        start_time = time.time()
        vertices, road_map = create_road_map(100, 5, i)
        path_lengths, path_distances = execute_search_on_locations(start_locations, goal_locations, road_map)
        average_path_length = sum(path_lengths)/len(path_lengths)
        average_path_distances = sum(path_distances)/ len(path_distances)
        print("avg path length", average_path_length)
        print("avg path distances", average_path_distances)
        print("time taken", (time.time()-start_time))



if __name__ == '__main__':
	print("new main called")
	main()
